// 入口

// import { setCookie,setBegin } from './setPlugCookie'
require ('./setPlugCookie')